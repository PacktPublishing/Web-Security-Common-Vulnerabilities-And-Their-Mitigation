<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Iframes - annoying iframe</title>
</head>
<body>
  <h3> This is a pretty annoying iframe </h3>
  <script>
    window.onload = function() {
      setTimeout(function() { alert("Hello - am I annoying you yet? "); }, 3000);
    }
  </script>
</body>
</html>
