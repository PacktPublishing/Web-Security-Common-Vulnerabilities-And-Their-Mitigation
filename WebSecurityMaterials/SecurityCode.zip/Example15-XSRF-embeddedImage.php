<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>XSRF</title>
</head>
<body>
  <h3>Here is a pic you might like!</h3>
  <img src="http://localhost/security/Example16-XSRF-transferFunds.php/?from_id=3333&to_id=1234&amount=1000">
</body>
</html>