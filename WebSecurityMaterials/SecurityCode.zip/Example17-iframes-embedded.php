<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Iframes - embedded</title>
</head>
<body>
  <iframe src = "http://nytimes.com" height="400px" width="600px"
          scrolling="yes" frameborder="0">
  </iframe>
  <iframe src = "Example18-iframes-annoying.php" height="400px" width="600px"
          scrolling="yes" frameborder="0">
  </iframe>
</body>
</html>
